
<html>
<head>
<link rel='stylesheet' href='ex.css'>
</head>
<body>

<main>
<div class="register">
<form>
 <h1><b> <i>Login</i></b></h1>
<label>UserName </label>
<input type="text"><br>
<label>Password </label>
<input type="password"><br>
<button> Login</button>
<p><b> Already registered? <a href="C:\Users\Kesava Trinadh\login.html">signin here</a></b></p>
</form>
</div>
</main>

</body>
</html>